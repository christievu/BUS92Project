#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 24 16:56:08 2018

@author: Matthew
"""

import pandas
import pygame
from appJar import gui

def press(btn):
    if btn == "Exit": 
        app.stop()

#Show the names of singers
    elif btn == "Display Singer's Names":
#reads the csv file and assigns it to the data dataframe
        data = pandas.read_csv("database.csv")
#assigns data from the first column to the firstnames object
        singernames = data.singer
#converts firstnames to a list
        singernamesl = singernames.tolist()
#establishes a subwindow called "Singers"
        app.startSubWindow("Singers")
        app.showSubWindow("Singers")    
        app.setSize(500,500)
        app.setLocation("CENTER")
#the following code adds a label to the subwindow for each
#item in the first column of the dataframe as assigned to
#singernamesl
        count=1
        for first in singernamesl:
            app.addLabel("label"+str(count),first)
            count = count+1        


#Show the names of singers DESCENDING ORDER
    elif btn == "Display Singer's Names in Descending Order":
        datasorted = pandas.read_csv("database.csv")
#reads the csv file and assigns it to the data dataframe
        datasorted = datasorted.sort_values("singer", ascending=False)
#assigns data from the first column to the firstnames object
        singernamesd = datasorted.singer
#converts firstnames to a list
        singernamesld = singernamesd.tolist()
#establishes a subwindow called "Singers"
        app.startSubWindow("Singers Descending")
        app.showSubWindow("Singers Descending")    
        app.setSize(500,500)
        app.setLocation("CENTER")
#the following code adds a label to the subwindow for each
#item in the first column of the dataframe as assigned to
#singernamesl
        count=1
        for first in singernamesld:
            app.addLabel("label2"+str(count),first)
            count = count+1
            
#Show the names of singers ASCENDING ORDER
    elif btn == "Display Singer's Names in Ascending Order":
        datasorted2 = pandas.read_csv("database.csv")
#reads the csv file and assigns it to the data dataframe
        datasorted2 = datasorted2.sort_values("singer", ascending=True)
#assigns data from the first column to the firstnames object
        singernamesd = datasorted2.singer
#converts firstnames to a list
        singernamesld = singernamesd.tolist()
#establishes a subwindow called "Singers"
        app.startSubWindow("Singers Ascending")
        app.showSubWindow("Singers Ascending")    
        app.setSize(500,500)
        app.setLocation("CENTER")
#the following code adds a label to the subwindow for each
#item in the first column of the dataframe as assigned to
#singernamesl
        count=1
        for first in singernamesld:
            app.addLabel("label3"+str(count),first)
            count = count+1    


#Find the biography of a singer
    elif btn == "Enter a Singer's Bio":
#shows a popup to ask user for a first name
        dataentered = pandas.read_csv("database.csv")
        dataentered.loc[dataentered["singer"]=="Post Malone", "bio"] = app.stringBox("singer","Enter a Biography")


#Find the biography of a singer
    elif btn == "Find Singer's Bio":
#shows a popup to ask user for a first name
        findname = app.stringBox("Singer","Enter the Singer's Full Name")
#reads the csv file and assigns it to the dataframe named data    
        data = pandas.read_csv("database.csv")
#finds the username based on the user entered first name
        answername = data[data.singer==findname].bio
#conversion of the search result to a list
        answernamel = answername.tolist()
#displays to search result in a popup
        app.infoBox("Singer's Bio:",answernamel)
        
    elif btn == "Play Songs":
        app.startSubWindow("Songs",modal=True)
        app.showSubWindow("Songs")
        app.setSize(500,500)
        app.setLocation("CENTER")
        app.addButton("New Light",press)
        app.addButton("Thank U, Next",press)
        app.addButton("Happier",press)
        app.addButton("Girls Like You",press)
        app.addButton("Pause Music",press)
        
    elif btn == "New Light":
        file = 'newlight.mp3'
        pygame.init()
        pygame.mixer.init()
        pygame.mixer.music.load(file)
        pygame.mixer.music.play()
        pygame.event.wait()
        
    elif btn == "Thank U, Next":
        file = 'thanku.mp3'
        pygame.init()
        pygame.mixer.init()
        pygame.mixer.music.load(file)
        pygame.mixer.music.play()
        pygame.event.wait()
        
    elif btn == "Happier":
        file = 'happier.mp3'
        pygame.init()
        pygame.mixer.init()
        pygame.mixer.music.load(file)
        pygame.mixer.music.play()
        pygame.event.wait()
        
    elif btn == "Girls Like You":
        file = 'girls.mp3'
        pygame.init()
        pygame.mixer.init()
        pygame.mixer.music.load(file)
        pygame.mixer.music.play()
        pygame.event.wait()
        
    elif btn == "Pause Music": 
        file = 'newlight.mp3'
        pygame.init()
        pygame.mixer.init()
        pygame.mixer.music.load(file)
        pygame.mixer.pause()
        
def close():
#stops and destroys to window so that you can re-create
#it from scratch with new data as needed
    app.stopSubWindow()
    app.destroySubWindow("one")
        
#GUI
app=gui("Main Menu","800x800")
app.addLabel("title", "Music Player")
app.setLabelBg("title", "teal")
app.addImage("decor","lol.gif")
app.setFont(32)

# 3 buttons, each calling the same function
app.addButton("Display Singer's Names",press)
app.addButton("Display Singer's Names in Descending Order",press)
app.addButton("Display Singer's Names in Ascending Order",press)
app.addButton("Enter a Singer's Bio",press)
app.addButton("Find Singer's Bio",press)
app.addButton("Play Songs",press)
app.addButton("Exit",press)
app.go() 