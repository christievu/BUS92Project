import pygame
file = '/Users/Matthew/Desktop/Test/song.mp3'
pygame.init()
pygame.mixer.init()
pygame.mixer.music.load(file)
pygame.mixer.music.play()
pygame.event.wait()

while pygame.mixer.music.get_busy(): 
  pygame.time.Clock().tick(10)